<?php
// Add custom Theme Functions here
update_option( 'flatsome_wup_purchase_code', '846b8d75-85b3-4b3e-976c-2e29d386339d' );
update_option( 'flatsome_wup_supported_until', '01.01.2050' );
update_option( 'flatsome_wup_buyer', 'Licensed' );
update_option( 'flatsome_wup_sold_at', time() );
delete_option( 'flatsome_wup_errors');
delete_option( 'flatsome_wupdates');
add_action('admin_head', 'custom_css_backend');
function custom_css_backend() {
echo '<style>#flatsome-notice {display: none;}</style>';}
